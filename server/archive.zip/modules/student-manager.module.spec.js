"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const student_manager_module_1 = __importDefault(require("./student-manager.module"));
const studentData = {
    name: "Ahmed Mohammed",
    age: 20,
    hobbies: [
        { name: "Football", description: "Play football" },
    ]
};
let student;
describe("Student Manager Class", () => {
    beforeAll(() => {
        student = new student_manager_module_1.default(studentData);
    });
    it("1. Should set & get student name", () => {
        student.setName("Ahmed Mohammed Mahmoud");
        expect(student.getName()).toBe("Ahmed Mohammed Mahmoud");
    });
    it("2. Should set & get student age", () => {
        student.setAge(21);
        expect(student.getAge()).toBe(21);
    });
});
