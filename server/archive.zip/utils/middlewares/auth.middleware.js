"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authGuard = void 0;
const users_entity_1 = __importDefault(require("../../entities/users.entity"));
const env_helper_1 = __importDefault(require("../../utils/helpers/env.helper"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const _usersEntity = new users_entity_1.default();
const authGuard = (req, res, next) => {
    try {
        // get authorization header
        const { authorization } = req.headers;
        // check if token is present
        if (!authorization)
            throw new Error("No token provided.");
        // check if token is valid
        const token = authorization.split(" ")[1];
        if (!token)
            throw new Error("Invalid token header.");
        // verify token
        const tokenUser = jsonwebtoken_1.default.verify(token, (0, env_helper_1.default)("JWT_SECRET"));
        if (!tokenUser)
            throw new Error("Invalid token.");
        // get user from database
        const user = _usersEntity.getByUsername(tokenUser.sub);
        // check if user exists
        if (!user)
            throw new Error("User does not exist.");
        // attach user to request
        res.locals.user = user;
        // call next middleware
        next();
    }
    catch (error) {
        return res.status(401).json({ message: error === null || error === void 0 ? void 0 : error.message });
    }
};
exports.authGuard = authGuard;
